from app.db_model.tables.draft_law import DraftLaw
from app.db_model.tables.resource import Resource

__all__ = [
    'DraftLaw',
    'Resource',
]