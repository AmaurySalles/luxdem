window.addEventListener('load', function () {
    const closeErrorOverlay = () => {
        const toggleBtn = document.querySelector('#dash-debug-menu__errors-button');
        const closeBtn = document.querySelector('.dash-fe-error__icon-x');

        // Only close the error overlay if the Errors button is NOT selected/open
        const isToggleActive = toggleBtn && toggleBtn.classList.contains('dash-debug-menu__button--selected');

        if (!isToggleActive && closeBtn) {
            closeBtn.click();
        } else {
            // If the overlay is open because the user wants it, stop retrying
            // Otherwise, keep retrying in case the overlay appears later
            if (!isToggleActive) {
                setTimeout(closeErrorOverlay, 500);
            }
        }
    };

    setTimeout(closeErrorOverlay, 500);

    // Observe DOM changes to handle navigation in Dash apps
    const targetNode = document.querySelector('#react-entry-point');
    if (targetNode) {
        const observer = new MutationObserver(() => {
            closeErrorOverlay();
        });
        observer.observe(targetNode, { childList: true, subtree: true });
    }
});
